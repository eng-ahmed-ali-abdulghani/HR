<header class="main-header">
    <div class="header-content">
        <!-- Mobile Menu Toggle -->
        <button class="mobile-menu-toggle d-md-none" id="mobileMenuToggle">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Title -->
        <div class="page-title">
            <h4><?php echo $__env->yieldContent('page-title', 'لوحة التحكم'); ?></h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ol>
            </nav>
        </div>

        <!-- Header Actions -->
        <div class="header-actions">
            <!-- Notifications -->

            <!-- User Profile -->
            <div class="dropdown">
                <button class="btn btn-header-action dropdown-toggle user-dropdown" type="button"
                        data-bs-toggle="dropdown">
                    <img src="https://picsum.photos/200?random=25" alt="User Avatar" class="user-avatar">
                    <span class="user-name"><?php echo e(Auth::user()->name ?? 'المدير العام'); ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li class="dropdown-header">
                        <div class="user-info-dropdown">
                            <img src="https://picsum.photos/200?random=25" alt="User Avatar">
                            <div>
                                <h6><?php echo e(Auth::user()->name ?? 'المدير العام'); ?></h6>
                                <small><?php echo e(Auth::user()->email ?? 'admin@example.com'); ?></small>
                            </div>
                        </div>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <form action="#" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>
                                تسجيل الخروج
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\HR\resources\views/dashboard/layouts/header.blade.php ENDPATH**/ ?>