<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="d-flex justify-content-center align-items-center">
            <div class="title-box">
                <h2 class="pages_heading">New Vacation Requests</h2>
            </div>
        </div>
        <div class="d-flex w-100 table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col ">#</th>
                        <th class="long-cell" scope="col">Code</th>
                        <th class="long-cell" scope="col">Name</th>
                        <th class="long-cell" scope="col">title</th>
                        <th class="long-cell" scope="col">Type</th>
                        <th class="long-cell" scope="col">Reason</th>
                        <th class="long-cell" scope="col">Alternative</th>
                        <th class="long-cell" scope="col">Date</th>
                        <th class="long-cell" scope="col">Note</th>
                        <th class="long-cell" scope="col">Period</th>
                        <th class="long-cell" scope="col">Leader Approve</th>
                        <th class="long-cell" scope="col">Control</th>
                    </tr>
                </thead>
                <tbody id="stock-table-body">
                    <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="long-cell"><?php echo e($vacation->user->code); ?></td>
                            <td class="long-cell"><?php echo e($vacation->user->username); ?></td>
                            <td class="long-cell"><?php echo e($vacation->user->title); ?></td>
                            <td class="long-cell"><?php echo e($vacation->type->name); ?></td>
                            <td class="long-cell"><?php echo e($vacation->reason->name); ?></td>
                            <td class="long-cell"><?php echo e($vacation->alternative ? $vacation->alternative->username : ''); ?></td>
                            <td class="long-cell"><?php echo e($vacation->date); ?></td>
                            <td class="long-cell"><?php echo e($vacation->note); ?></td>
                            <td class="long-cell"><?php echo e($vacation->day == '1' ? 'full' : 'half'); ?></td>
                            <td class="long-cell">
                                <?php echo $vacation->leader_approve == '1'
                                    ? '<i class="fa-solid fa-check" style="color: #008f64;"></i>'
                                    : ($vacation->leader_approve == '0'
                                        ? '<i class="fa-solid fa-xmark" style="color: #ff0000;"></i>'
                                        : '<i class="fa-solid fa-minus"></i>'); ?>

                            </td>

                            <td class="long-cell"><?php echo e($vacation->statu->name_en); ?></td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hr_may\resources\views/dashboard/Pages/Vacations/newRequests.blade.php ENDPATH**/ ?>
